These files were generated with openssl v0.9.6a-engine based on the
instructions at http://www-itg.lbl.gov/~boverhof/openssl_certs.html.
The file names match the examples used above.

The PEM password is 'sample' with the basic CA info being:

subject=/C=CA/ST=British Columbia/L=Vancouver/O=Sample Certs Intl

These are for testing use only.
